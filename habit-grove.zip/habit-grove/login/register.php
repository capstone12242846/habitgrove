<?php
include("../db/connect.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $username = trim($_POST["username"]);
  $email = trim($_POST["email"]);
  $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

  $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $username, $email, $password);
  if ($stmt->execute()) {
    header("Location: login.php");
    exit();
  } else {
    $error = "Error: " . $stmt->error;
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | Habit Grove 🌱</title>
<link rel="stylesheet" href="../styles/global.css">
<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: var(--bg);
}
.auth-card {
  background: var(--card-bg);
  padding: 2rem 2.5rem;
  border-radius: var(--radius);
  box-shadow: 0 6px 20px var(--shadow);
  width: 100%;
  max-width: 400px;
}
.auth-card h1 {
  text-align: center;
  color: var(--primary-dark);
  margin-bottom: 1.5rem;
}
.auth-card form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.auth-card input {
  padding: 0.8rem 1rem;
  border-radius: var(--radius);
  border: 1px solid var(--border);
}
.auth-card button {
  padding: 0.8rem;
  border: none;
  border-radius: var(--radius);
  background: var(--primary);
  color: #fff;
  font-weight: 600;
  cursor: pointer;
  transition: background var(--transition);
}
.auth-card button:hover {
  background: var(--primary-dark);
}
.auth-card .links {
  text-align: center;
  margin-top: 1rem;
}
.auth-card .links a {
  color: var(--primary);
  text-decoration: none;
  font-weight: 500;
}
.auth-card .error {
  color: #dc2626;
  text-align: center;
  margin-bottom: 0.8rem;
}
</style>
</head>
<body>
<div class="auth-card">
  <h1>Register</h1>
  <?php if(isset($error)) echo "<div class='error'>{$error}</div>"; ?>
  <form method="POST">
    <input name="username" placeholder="Username" required>
    <input name="email" type="email" placeholder="Email" required>
    <input name="password" type="password" placeholder="Password" required>
    <button type="submit">Register</button>
  </form>
  <div class="links">
    <a href="login.php">Already have an account? Login</a>
  </div>
</div>
</body>
</html>
