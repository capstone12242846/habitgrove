<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors',0);
ini_set('log_errors',1);

$logFile = __DIR__.'/save_budget_errors.log';
function log_error($msg){ global $logFile; @file_put_contents($logFile, date('Y-m-d H:i:s')." - ".$msg.PHP_EOL, FILE_APPEND|LOCK_EX); }

$dbPath = __DIR__.'/../db/connect.php';
if(!file_exists($dbPath)){ echo json_encode(['error'=>"db_connect.php not found"]); exit; }
require_once $dbPath;

if(!isset($_SESSION['user_id'])){ http_response_code(401); echo json_encode(['error'=>'Not logged in']); exit; }
$user_id = (int)$_SESSION['user_id'];

try{
  $action = $_GET['action']??null;
  $method = $_SERVER['REQUEST_METHOD'];
  $raw = file_get_contents('php://input');
  $data = json_decode($raw,true);

  // CREATE TABLE if missing
  $conn->query("
    CREATE TABLE IF NOT EXISTS budgets(
      id INT PRIMARY KEY AUTO_INCREMENT,
      user_id INT NOT NULL,
      category VARCHAR(255) NOT NULL,
      type ENUM('income','expense') NOT NULL DEFAULT 'expense',
      amount DECIMAL(10,2) NOT NULL,
      note TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");

  // ---------------- GET: load ----------------
  if($method==='GET' && $action==='load'){
    $stmt = $conn->prepare("SELECT * FROM budgets WHERE user_id=? ORDER BY created_at DESC");
    $stmt->bind_param('i',$user_id);
    $stmt->execute();
    $res=$stmt->get_result();
    $rows=$res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    echo json_encode($rows); exit;
  }

  // ---------------- POST actions ----------------
  if($method==='POST' && is_array($data)){
    $act = $data['action']??null;

    if($act==='add'){
      $category=trim($data['category']??'');
      $type=($data['type']==='income')?'income':'expense';
      $amount=floatval($data['amount']??0);
      $note=trim($data['note']??'');
      if($category===''||$amount<=0){ echo json_encode(['error'=>'Invalid input']); exit; }
      $stmt=$conn->prepare("INSERT INTO budgets (user_id, category, type, amount, note) VALUES (?,?,?, ?, ?)");
      $stmt->bind_param('issds',$user_id,$category,$type,$amount,$note);
      $stmt->execute(); $stmt->close();
      echo json_encode(['status'=>'ok']); exit;
    }

    if($act==='delete'){
      $id=(int)($data['id']??0); if($id<=0){ echo json_encode(['error'=>'invalid id']); exit; }
      $stmt=$conn->prepare("DELETE FROM budgets WHERE id=? AND user_id=?");
      $stmt->bind_param('ii',$id,$user_id);
      $stmt->execute(); $stmt->close();
      echo json_encode(['status'=>'ok']); exit;
    }

    if($act==='edit'){
      $id=(int)($data['id']??0); if($id<=0){ echo json_encode(['error'=>'invalid id']); exit; }
      $category=trim($data['category']??'');
      $type=($data['type']==='income')?'income':'expense';
      $amount=floatval($data['amount']??0);
      $note=trim($data['note']??'');
      $stmt=$conn->prepare("UPDATE budgets SET category=?, type=?, amount=?, note=? WHERE id=? AND user_id=?");
      $stmt->bind_param('ssdsi',$category,$type,$amount,$note,$id,$user_id);
      $stmt->execute(); $stmt->close();
      echo json_encode(['status'=>'ok']); exit;
    }

    echo json_encode(['error'=>'unknown action']); exit;
  }

  http_response_code(405);
  echo json_encode(['error'=>'method_not_allowed']);
}catch(Throwable $e){
  log_error($e->getMessage());
  http_response_code(500);
  echo json_encode(['error'=>'server_error','message'=>$e->getMessage()]);
}
