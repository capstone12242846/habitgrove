<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login/login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Budget | Habit Grove</title>
<link rel="stylesheet" href="../styles/global.css" />
<style>
/* ─── BUDGET PAGE COHESIVE STYLES ───────────────────────── */

/* Main container */
main.container {
    margin-top: 2rem;
}

/* Page heading */
h1 {
    color: var(--primary-dark);
    margin-bottom: 0.5rem;
}

/* Small muted description */
.small-muted {
    color: var(--text-light);
    font-size: 0.85rem;
    margin-bottom: 1rem;
}

/* Add budget form */
.add-budget {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
}

.add-budget input,
.add-budget select {
    padding: 0.5rem 0.75rem;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    min-width: 120px;
    font-size: 0.95rem;
}

.add-budget button {
    background: var(--primary);
    color: #fff;
    padding: 0.5rem 1rem;
    border-radius: var(--radius);
    border: none;
    cursor: pointer;
    font-weight: 500;
    transition: var(--transition);
}

.add-budget button:hover {
    background: var(--primary-dark);
}

/* Budget table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
    font-size: 0.95rem;
}

th, td {
    padding: 0.75rem 1rem;
    text-align: left;
    border-bottom: 1px solid var(--border);
}

th {
    background: var(--bg-accent);
    color: var(--primary-dark);
}

tr:nth-child(even) {
    background: var(--bg);
}

/* Action buttons */
td .budget-actions button {
    margin-right: 0.5rem;
    border-radius: var(--radius);
    padding: 0.4rem 0.8rem;    
    cursor: pointer;
    border: none;
    font-weight: 500;
    transition: var(--transition);
}

td .budget-actions .edit {
    background: var(--secondary);
    color: #fff;
}

td .budget-actions .edit:hover {
    background: var(--primary);
}

td .budget-actions .delete {
    background: #f28b82;
    color: #fff;
}

td .budget-actions .delete:hover {
    background: #e53935;
}

/* Status select dropdown */
.status-select {
    border-radius: var(--radius);
    padding: 0.4rem 0.6rem;
    border: 1px solid var(--border);
    background: var(--card-bg);
    color: var(--text);
}

/* Reviewed checkbox label */
.checked-label {
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
}

input.reviewed {
    accent-color: var(--primary);
    cursor: pointer;
}

/* Responsive adjustments */
@media(max-width: 768px) {
    .add-budget input,
    .add-budget select,
    .add-budget button {
        width: 100%;
    }
}
</style>
</head>
<body>
<?php include('../navbar.php'); ?>

<main class="container">
<h1>💰 Your Budget</h1>
<p class="small-muted">Track your income and expenses. Edit, delete or add categories and amounts.</p>

<div class="add-budget">
  <input type="text" id="category" placeholder="Category">
  <input type="number" id="amount" placeholder="Amount" step="0.01">
  <select id="type">
    <option value="income">Income</option>
    <option value="expense" selected>Expense</option>
  </select>
  <input type="text" id="note" placeholder="Note (optional)">
  <button id="addBtn">Add</button>
</div>

<table>
  <thead>
    <tr>
      <th>Category</th>
      <th>Amount</th>
      <th>Type</th>
      <th>Note</th>
      <th>Status</th>
      <th>Reviewed</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody id="budget-body">
    <tr><td colspan="7" class="small-muted">Loading budgets…</td></tr>
  </tbody>
</table>
</main>

<script>
/* All existing JS functionality untouched */
const API = 'save_budget.php';
const body = document.getElementById('budget-body');
const addBtn = document.getElementById('addBtn');

async function loadBudgets() {
  try {
    const res = await fetch(API+'?action=load', { credentials:'same-origin' });
    const text = await res.text();
    const data = JSON.parse(text);
    if (!Array.isArray(data) || data.length===0) {
      body.innerHTML = '<tr><td colspan="7" class="small-muted">No budgets yet — add one!</td></tr>';
      return;
    }

    body.innerHTML = data.map(b=>{
      return `<tr data-id="${b.id}">
        <td>${b.category}</td>
        <td>${b.amount}</td>
        <td>${b.type}</td>
        <td>${b.note||''}</td>
        <td>
          <select class="status-select" data-id="${b.id}" data-field="status">
            <option value="Planned" ${b.status==='Planned'?'selected':''}>Planned</option>
            <option value="Received" ${b.status==='Received'?'selected':''}>Received</option>
            <option value="Spent" ${b.status==='Spent'?'selected':''}>Spent</option>
          </select>
        </td>
        <td>
          <label class="checked-label">
            <input type="checkbox" class="reviewed" data-id="${b.id}" ${b.reviewed=='1'?'checked':''}>
          </label>
        </td>
        <td class="budget-actions">
          <button class="edit" data-id="${b.id}">Edit</button>
          <button class="delete" data-id="${b.id}">Delete</button>
        </td>
      </tr>`;
    }).join('');

    document.querySelectorAll('.edit').forEach(btn=>{
      btn.onclick = ()=>editBudget(btn.dataset.id);
    });
    document.querySelectorAll('.delete').forEach(btn=>{
      btn.onclick = ()=>deleteBudget(btn.dataset.id);
    });
    document.querySelectorAll('.status-select').forEach(el=>{
      el.addEventListener('change', async ()=>{
        const id = el.dataset.id, value = el.value;
        await fetch(API,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action:'edit-field',id,field:'status',value})
        });
        loadBudgets();
      });
    });
    document.querySelectorAll('.reviewed').forEach(el=>{
      el.addEventListener('change', async ()=>{
        const id = el.dataset.id, value = el.checked?1:0;
        await fetch(API,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action:'set-reviewed',id,value})
        });
      });
    });
  } catch(e){
    body.innerHTML = '<tr><td colspan="7" class="small-muted">Failed loading budgets — check console</td></tr>';
    console.error(e);
  }
}

addBtn.onclick = async ()=>{
  const category = document.getElementById('category').value.trim();
  const amount = parseFloat(document.getElementById('amount').value);
  const type = document.getElementById('type').value;
  const note = document.getElementById('note').value.trim();
  if(!category || isNaN(amount)) return alert('Category and amount required');
  addBtn.disabled=true;
  try{
    const res = await fetch(API,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({action:'add',category,amount,type,note})
    });
    const j = await res.json();
    if(j.error) throw new Error(j.error);
    document.getElementById('category').value='';
    document.getElementById('amount').value='';
    document.getElementById('note').value='';
    await loadBudgets();
  } catch(e){ alert(e.message); }
  finally{ addBtn.disabled=false; }
}

async function editBudget(id){
  const row = document.querySelector(`tr[data-id='${id}']`);
  const category = prompt('Category:', row.children[0].innerText);
  const amount = prompt('Amount:', row.children[1].innerText);
  const type = prompt('Type (income/expense):', row.children[2].innerText);
  const note = prompt('Note:', row.children[3].innerText);
  if(!category || isNaN(amount) || !type) return;
  try{
    const res = await fetch(API,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({action:'edit',id,category,amount,type,note})
    });
    const j = await res.json();
    if(j.error) throw new Error(j.error);
    await loadBudgets();
  } catch(e){ alert(e.message); }
}

async function deleteBudget(id){
  if(!confirm('Delete this budget entry?')) return;
  try{
    const res = await fetch(API,{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({action:'delete',id})
    });
    const j = await res.json();
    if(j.error) throw new Error(j.error);
    await loadBudgets();
  } catch(e){ alert(e.message); }
}

document.addEventListener('DOMContentLoaded', loadBudgets);
</script>
</body>
</html>
