<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login/login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Habit Tracker | Habit Grove</title>
<link rel="stylesheet" href="../styles/global.css" />
<style>
/* ─── MAIN CONTAINER ───────────────────── */
main.container {
    max-width: 1000px;
    margin: 2rem auto;
    padding: 1.5rem;
}

/* ─── PAGE TITLE ───────────────────────── */
h1 {
    text-align: center;
    color: var(--primary-dark);
    margin-bottom: 2rem;
}

/* ─── HABIT INPUT / BUTTONS ───────────── */
.habit-controls {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 2rem;
}

.habit-controls input {
    flex-grow: 1;
    padding: 0.6rem 1rem;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    font-size: 1rem;
}

.habit-controls button {
    padding: 0.6rem 1.5rem;
    border-radius: var(--radius);
    border: none;
    background: var(--primary);
    color: #fff;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
}

.habit-controls button:hover {
    background: var(--primary-dark);
}

/* ─── TABLE ────────────────────────────── */
table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: 0 4px 12px var(--shadow);
    background: var(--card-bg);
}

th, td {
    padding: 0.6rem;
    text-align: center;
    border: 1px solid var(--border);
    font-size: 0.95rem;
}

th {
    background-color: var(--bg-accent);
    color: var(--primary-dark);
    font-weight: 600;
}

td.done {
    background-color: #c4f0c4;
}

input[type="checkbox"] {
    width: 22px;
    height: 22px;
    accent-color: var(--primary);
    cursor: pointer;
}

button.delete-btn {
    background: #f28b82;
    border: none;
    color: white;
    border-radius: 50%;
    padding: 0 0.5rem;
    cursor: pointer;
    transition: var(--transition);
}

button.delete-btn:hover {
    background: #e53935;
}

/* ─── RESPONSIVE ───────────────────────── */
@media(max-width: 800px) {
    th, td { font-size: 0.8rem; padding: 0.4rem; }
}
</style>
</head>
<body>
<?php include('../navbar.php'); ?>

<main class="container">
<h1>📅 Habit Calendar</h1>

<div class="habit-controls">
    <input type="text" id="newHabit" placeholder="New habit name">
    <button onclick="addHabit()">Add Habit</button>
</div>

<table>
    <thead>
        <tr id="calendarHeader">
            <th>Habit</th>
        </tr>
    </thead>
    <tbody id="calendarBody">
        <tr><td colspan="8">Loading habits…</td></tr>
    </tbody>
</table>
</main>

<script>
let habits = [];
let habitData = {};
const userId = <?php echo $user_id; ?>;

// Fetch habits from server
async function loadHabits() {
    const res = await fetch('save_habit.php?action=get');
    const data = await res.json();
    habits = data.habits;
    habitData = data.habitData;
    renderCalendar();
}

// Add habit
async function addHabit() {
    const input = document.getElementById('newHabit');
    const name = input.value.trim();
    if(!name) return alert("Enter a habit name");

    const res = await fetch('save_habit.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: `action=add&habit_name=${encodeURIComponent(name)}`
    });
    const data = await res.json();
    if(data.success){
        input.value = '';
        loadHabits();
    } else alert('Error adding habit');
}

// Delete habit
async function deleteHabit(id){
    if(!confirm('Delete this habit?')) return;
    const res = await fetch('save_habit.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: `action=delete&habit_id=${id}`
    });
    const data = await res.json();
    if(data.success) loadHabits();
}

// Toggle done
async function toggleHabit(date, id, checkbox){
    const done = checkbox.checked ? 1 : 0;
    const res = await fetch('save_habit.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: `action=toggle&habit_id=${id}&date=${date}&done=${done}`
    });
    const data = await res.json();
    if(!data.success) checkbox.checked = !checkbox.checked;
    loadHabits();
}

// Calendar helpers
function getNext7Days(){
    const days = [];
    const today = new Date();
    for(let i=0;i<7;i++){
        const d = new Date(today);
        d.setDate(today.getDate()+i);
        days.push(d);
    }
    return days;
}

function renderCalendar(){
    const tableHead = document.getElementById('calendarHeader');
    const tableBody = document.getElementById('calendarBody');
    const days = getNext7Days();

    tableHead.innerHTML = '<th>Habit</th>';
    days.forEach(d=>{
        const dayStr = `${d.getDate().toString().padStart(2,'0')}/${(d.getMonth()+1).toString().padStart(2,'0')}/${d.getFullYear().toString().slice(2)}`;
        tableHead.innerHTML += `<th>${dayStr}</th>`;
    });

    tableBody.innerHTML = '';
    if(habits.length === 0){
        tableBody.innerHTML = '<tr><td colspan="8">No habits yet — add one above!</td></tr>';
        return;
    }

    habits.forEach(h=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${h.habit_name} <button class="delete-btn" onclick="deleteHabit(${h.id})">✖</button></td>`;
        days.forEach(d=>{
            const dateStr = `${d.getFullYear()}-${(d.getMonth()+1).toString().padStart(2,'0')}-${d.getDate().toString().padStart(2,'0')}`;
            const done = habitData[dateStr]?.[h.id] ? 'checked' : '';
            tr.innerHTML += `<td class="${done?'done':''}"><input type="checkbox" ${done} onchange="toggleHabit('${dateStr}',${h.id},this)"></td>`;
        });
        tableBody.appendChild(tr);
    });
}

loadHabits();
</script>
</body>
</html>
