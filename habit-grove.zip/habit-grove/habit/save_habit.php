<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success'=>false, 'msg'=>'Not logged in']);
    exit();
}
$user_id = $_SESSION["user_id"];
require_once('../db/connect.php');

$action = $_REQUEST['action'] ?? '';

if($action == 'get'){
    // Fetch habits
    $habits = [];
    $stmt = $conn->prepare("SELECT * FROM habits WHERE user_id=? ORDER BY id DESC");
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while($row = $res->fetch_assoc()){
        $habits[] = $row;
    }

    // Fetch habit logs
    $habitData = [];
    $stmt = $conn->prepare("SELECT habit_id, log_date, done FROM habits_log WHERE habit_id IN (SELECT id FROM habits WHERE user_id=?)");
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while($row = $res->fetch_assoc()){
        $habitData[$row['log_date']][$row['habit_id']] = $row['done'];
    }

    echo json_encode(['habits'=>$habits,'habitData'=>$habitData]);
    exit();
}

if($action == 'add'){
    $habit_name = trim($_POST['habit_name'] ?? '');
    if(!$habit_name) exit(json_encode(['success'=>false]));

    $stmt = $conn->prepare("INSERT INTO habits(user_id, habit_name) VALUES(?,?)");
    $stmt->bind_param("is",$user_id,$habit_name);
    $stmt->execute();
    echo json_encode(['success'=>true]);
    exit();
}

if($action == 'delete'){
    $habit_id = intval($_POST['habit_id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM habits WHERE id=? AND user_id=?");
    $stmt->bind_param("ii",$habit_id,$user_id);
    $stmt->execute();
    echo json_encode(['success'=>true]);
    exit();
}

if($action == 'toggle'){
    $habit_id = intval($_POST['habit_id'] ?? 0);
    $date = $_POST['date'] ?? '';
    $done = intval($_POST['done'] ?? 0);

    // Check if entry exists
    $stmt = $conn->prepare("SELECT id FROM habits_log WHERE habit_id=? AND log_date=?");
    $stmt->bind_param("is",$habit_id,$date);
    $stmt->execute();
    $res = $stmt->get_result();

    if($res->num_rows){
        $row = $res->fetch_assoc();
        $stmt = $conn->prepare("UPDATE habits_log SET done=? WHERE id=?");
        $stmt->bind_param("ii",$done,$row['id']);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("INSERT INTO habits_log(habit_id, log_date, done) VALUES(?,?,?)");
        $stmt->bind_param("isi",$habit_id,$date,$done);
        $stmt->execute();
    }
    echo json_encode(['success'=>true]);
    exit();
}
?>
