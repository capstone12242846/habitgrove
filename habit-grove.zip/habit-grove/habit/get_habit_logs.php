<?php
session_start();
if(!isset($_SESSION['user_id'])) exit(json_encode([]));
$user_id = $_SESSION['user_id'];
include('../db/connect.php');

$logs = [];
$today = date('Y-m-d');
$end = date('Y-m-d', strtotime('+7 days'));

$sql = "SELECT h.id as habit_id, hl.log_date, hl.done
        FROM habits h
        LEFT JOIN habit_logs hl ON h.id=hl.habit_id AND hl.log_date BETWEEN ? AND ?
        WHERE h.user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi",$today,$end,$user_id);
$stmt->execute();
$res = $stmt->get_result();
while($row=$res->fetch_assoc()){
    if(!isset($logs[$row['log_date']])) $logs[$row['log_date']] = [];
    $logs[$row['log_date']][$row['habit_id']] = intval($row['done']);
}
echo json_encode($logs);
