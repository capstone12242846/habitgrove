<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login/login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Pomodoro Timer | Habit Grove 🌱</title>
<link rel="stylesheet" href="../styles/global.css" />
<style>
/* ─── BASE STYLES ───────────────────────── */
body {
  background: var(--bg);
  font-family: var(--font-main);
  color: var(--text);
  margin:0;
}

main.container {
  max-width:1200px;
  margin:28px auto;
  padding:20px;
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:20px;
}

.card {
  background: var(--card-bg);
  border-radius: var(--radius);
  box-shadow:0 6px 20px var(--shadow);
  padding:20px;
  display:flex;
  flex-direction:column;
  align-items:center;
}

/* ─── TIMER CIRCLE ───────────────────────── */
.timer-circle {
  position: relative;
  width:100%;
  max-width:250px;
  aspect-ratio:1/1;
  margin:1rem auto;
}

.timer-circle svg {
  width:100%;
  height:100%;
  transform: rotate(-90deg);
}

.timer-circle circle.bg {
  stroke: var(--bg-accent);
}

.timer-circle circle.progress {
  stroke: var(--primary);
  stroke-linecap: round;
  stroke-dasharray:565.48;
  stroke-dashoffset:565.48;
  transition: stroke-dashoffset 0.3s linear;
}

.timer-display {
  position:absolute;
  top:50%;
  left:50%;
  transform:translate(-50%, -50%);
  font-size:2.5rem;
  font-weight:700;
  color: var(--primary);
  text-align:center;
}

.session-type {
  text-align:center;
  margin:0.8rem 0;
  color: var(--text-light);
  font-weight:500;
}

/* ─── PRESETS ───────────────────────── */
.preset-buttons {
  display:flex;
  justify-content:center;
  gap:10px;
  flex-wrap:wrap;
  margin-bottom:1rem;
}

.preset-buttons button {
  background: var(--bg-accent);
  color: var(--primary);
  border: 2px solid var(--primary);
  padding:0.5rem 1rem;
  border-radius: var(--radius);
  font-weight:500;
  cursor:pointer;
  transition: all 0.25s ease;
}

.preset-buttons button.active,
.preset-buttons button:hover {
  background: var(--primary);
  color:#fff;
}

/* ─── CONTROLS ───────────────────────── */
.controls {
  display:flex;
  justify-content:center;
  gap:0.75rem;
  flex-wrap:wrap;
  margin-bottom:1rem;
}

.controls button {
  background: var(--primary);
  color:#fff;
  border:none;
  padding:0.6rem 1.2rem;
  border-radius: var(--radius);
  font-weight:500;
  cursor:pointer;
  transition: all 0.25s ease;
}

.controls button:hover {
  background: var(--primary-dark);
}

/* ─── SESSION INFO ─────────────────────── */
.session-info {
  background: var(--bg);
  width:100%;
  padding:1rem 1.5rem;
  border-radius: var(--radius);
  color: var(--text);
  font-size:0.95rem;
}

.session-info p {
  margin:0.4rem 0;
}

/* ─── NOTES BOX ───────────────────────── */
.notes-box {
  width:100%;
}

.notes-header {
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-bottom:0.8rem;
}

.notes-header h2 {
  color: var(--primary);
  margin:0;
  font-size:1.4rem;
}

.notes-header button {
  background:none;
  border:none;
  font-size:1.2rem;
  cursor:pointer;
  color: var(--text-light);
  transition: all 0.25s ease;
}

.notes-header button:hover { color:#e53935; }

.notes-box textarea {
  width:100%;
  padding:1rem;
  font-family:inherit;
  font-size:0.95rem;
  border-radius: var(--radius);
  border:1px solid var(--border);
  resize:none;
  min-height:300px;
  color: var(--text);
  background:#fbfdfb;
  outline-color: var(--primary);
}

.note-hint {
  color: var(--text-light);
  font-size:0.85rem;
  margin-top:0.8rem;
}

/* ─── RESPONSIVE ─────────────────────── */
@media (max-width:900px){
  main.container { grid-template-columns:1fr; padding:15px; }
}
</style>
</head>
<body>
<?php include('../navbar.php'); ?>

<main class="container">
  <div class="card timer-box">
    <h1 style="color: #3c6823">⏰ Pomodoro Timer</h1>
    <p class="subtext">Focus deeply with structured work sessions</p>

    <div class="timer-circle">
      <svg viewBox="0 0 200 200">
        <circle class="bg" cx="100" cy="100" r="90" stroke-width="15" fill="none"/>
        <circle class="progress" cx="100" cy="100" r="90" stroke-width="15" fill="none"/>
      </svg>
      <div class="timer-display" id="timer">25:00</div>
    </div>

    <p class="session-type" id="sessionType">Work Session</p>

    <div class="preset-buttons">
      <button id="preset25" class="active" onclick="setPreset(25,5)">25 / 5</button>
      <button id="preset45" onclick="setPreset(45,15)">45 / 15</button>
    </div>

    <div class="controls">
      <button onclick="startTimer()">▶ Start</button>
      <button onclick="stopTimer()">⏸ Stop</button>
      <button onclick="breakEarly()">⏭ Break Early</button>
      <button onclick="resetTimer()">⟳ Reset</button>
    </div>

    <div class="session-info" id="sessionInfo">
      <p><strong>Work Duration:</strong> 25 minutes</p>
      <p><strong>Break Duration:</strong> 5 minutes</p>
      <p><strong>Current Mode:</strong> Work</p>
    </div>
  </div>

  <div class="card notes-box">
    <div class="notes-header">
      <h2>Session Notes</h2>
    </div>
    <textarea id="sessionNotes" placeholder="Write your session notes here..."></textarea>
    <br>
    <button title="Clear notes" onclick="clearNotes()">🗑</button>
    <p class="note-hint">💡 Notes are temporary. Refresh will clear them.</p>
  </div>
</main>

<script>
// Functionality unchanged
let workDuration=25*60, breakDuration=5*60, timeRemaining=workDuration;
let timer, mode='work';
const timerDisplay=document.getElementById('timer');
const sessionType=document.getElementById('sessionType');
const infoBox=document.getElementById('sessionInfo');
const preset25=document.getElementById('preset25');
const preset45=document.getElementById('preset45');
const progressCircle=document.querySelector('.timer-circle .progress');
const totalLength=2*Math.PI*90;

function updateDisplay(){
  const mins=Math.floor(timeRemaining/60).toString().padStart(2,'0');
  const secs=(timeRemaining%60).toString().padStart(2,'0');
  timerDisplay.textContent=`${mins}:${secs}`;
  const percent=(mode==='work'?timeRemaining/workDuration:timeRemaining/breakDuration);
  progressCircle.style.strokeDashoffset=totalLength*(1-percent);
}

function setPreset(work,brk){
  workDuration=work*60; breakDuration=brk*60; resetTimer();
  preset25.classList.toggle('active',work===25);
  preset45.classList.toggle('active',work===45);
  infoBox.innerHTML=`<p><strong>Work Duration:</strong> ${work} minutes</p>
  <p><strong>Break Duration:</strong> ${brk} minutes</p>
  <p><strong>Current Mode:</strong> Work</p>`;
}

function startTimer(){
  if(timer) return;
  timer=setInterval(()=>{
    timeRemaining--;
    updateDisplay();
    if(timeRemaining<=0){
      clearInterval(timer); timer=null;
      if(mode==='work'){
        mode='break'; timeRemaining=breakDuration;
        alert('Work session complete! Time for a break 🌿');
        sessionType.textContent='Break Time';
        infoBox.querySelectorAll('p')[2].innerHTML="<strong>Current Mode:</strong> Break";
        startTimer();
      } else {
        mode='work'; timeRemaining=workDuration;
        alert('Break finished! Back to work 💪');
        sessionType.textContent='Work Session';
        infoBox.querySelectorAll('p')[2].innerHTML="<strong>Current Mode:</strong> Work";
        updateDisplay();
      }
    }
  },1000);
}

function stopTimer(){ clearInterval(timer); timer=null; }

function breakEarly(){
  if(mode==='work'){
    stopTimer(); mode='break'; timeRemaining=breakDuration;
    alert('Switched early to break ⏭');
    sessionType.textContent='Break Time';
    infoBox.querySelectorAll('p')[2].innerHTML="<strong>Current Mode:</strong> Break";
    startTimer();
  }
}

function resetTimer(){
  stopTimer(); mode='work'; timeRemaining=workDuration;
  sessionType.textContent='Work Session';
  infoBox.querySelectorAll('p')[2].innerHTML="<strong>Current Mode:</strong> Work";
  updateDisplay();
}

// Notes
const notesArea=document.getElementById('sessionNotes');
notesArea.value=sessionStorage.getItem('pomodoroNotes')||'';
notesArea.addEventListener('input',()=>{ sessionStorage.setItem('pomodoroNotes',notesArea.value); });
function clearNotes(){ notesArea.value=''; sessionStorage.removeItem('pomodoroNotes'); }

updateDisplay();
</script>
</body>
</html>
