<?php
// save_grove_habit.php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

$logFile = __DIR__.'/save_grove_habit_errors.log';
function log_error($msg){ global $logFile; @file_put_contents($logFile,date('Y-m-d H:i:s')." - $msg\n", FILE_APPEND|LOCK_EX); }

ini_set('display_errors','0'); ini_set('log_errors','1');

// Correct DB path
$dbPath = __DIR__ . '/../db/connect.php';
if(!file_exists($dbPath)){
    http_response_code(500);
    $msg="connect.php not found at $dbPath";
    log_error($msg);
    echo json_encode(['error'=>$msg]); exit;
}
require_once $dbPath;
if(!isset($conn)||!($conn instanceof mysqli)){
    http_response_code(500);
    $msg="DB connection not found";
    log_error($msg);
    echo json_encode(['error'=>$msg]); exit;
}

if(!isset($_SESSION['user_id'])){
    http_response_code(401);
    echo json_encode(['error'=>'Not logged in']); exit;
}
$user_id=(int)$_SESSION['user_id'];

// Ensure table exists
$createSQL="CREATE TABLE IF NOT EXISTS grove_habits (
  id BIGINT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255),
  treeType VARCHAR(50),
  growth INT DEFAULT 0,
  decay INT DEFAULT 0,
  lastUpdated DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
if(!$conn->query($createSQL)) log_error("CREATE TABLE failed: ".$conn->error);

// Fetch habits
function fetch_habits(mysqli $conn,int $user_id):array{
    $stmt=$conn->prepare("SELECT id,user_id,name,treeType,growth,decay,lastUpdated FROM grove_habits WHERE user_id=? ORDER BY id DESC");
    if(!$stmt) return [];
    $stmt->bind_param('i',$user_id);
    $stmt->execute();
    $res=$stmt->get_result();
    $rows=$res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

$method=$_SERVER['REQUEST_METHOD'];
$action=$_GET['action']??null;

try{
    if($method==='GET' && ($action==='load'||$action===null)){
        echo json_encode(fetch_habits($conn,$user_id));
        exit;
    }

    $raw=file_get_contents('php://input');
    $data=json_decode($raw,true);

    if($method==='POST' && is_array($data)){
        $act=$data['action']??null;

        if($act==='add'){
            $name=trim((string)($data['name']??''));
            $treeType=trim((string)($data['treeType']??'flower'));
            if($name===''){ http_response_code(400); echo json_encode(['error'=>'name required']); exit; }
            $id=(int)round(microtime(true)*1000);
            $stmt=$conn->prepare("INSERT INTO grove_habits (id,user_id,name,treeType,growth,decay,lastUpdated) VALUES (?,?,?,?,0,0,NULL)");
            if(!$stmt) throw new Exception("Prepare failed: ".$conn->error);
            $stmt->bind_param('iiss',$id,$user_id,$name,$treeType);
            if(!$stmt->execute()) throw new Exception("Insert failed: ".$stmt->error);
            $stmt->close();
            echo json_encode(['status'=>'ok','id'=>$id]); exit;
        }

        if($act==='delete'){
            $id=(int)($data['id']??0); if($id<=0){http_response_code(400); echo json_encode(['error'=>'invalid id']); exit;}
            $stmt=$conn->prepare("DELETE FROM grove_habits WHERE id=? AND user_id=?");
            $stmt->bind_param('ii',$id,$user_id); $stmt->execute(); $stmt->close();
            echo json_encode(['status'=>'ok']); exit;
        }

        if($act==='grow'){
            $id=(int)($data['id']??0); if($id<=0){http_response_code(400); echo json_encode(['error'=>'invalid id']); exit;}
            $stmt=$conn->prepare("SELECT growth,decay,lastUpdated FROM grove_habits WHERE id=? AND user_id=? LIMIT 1");
            $stmt->bind_param('ii',$id,$user_id); $stmt->execute(); $res=$stmt->get_result();
            if($res->num_rows===0){ $stmt->close(); http_response_code(404); echo json_encode(['error'=>'not_found']); exit; }
            $row=$res->fetch_assoc(); $stmt->close();

            $today=date('Y-m-d'); $lastYmd=$row['lastUpdated']?date('Y-m-d',strtotime($row['lastUpdated'])):null;
            if($lastYmd===$today){ http_response_code(400); echo json_encode(['error'=>'already_grown_today']); exit; }

            $newGrowth=(int)$row['growth']; $newDecay=(int)$row['decay'];
            if($lastYmd && $lastYmd!==$today){ $diff=(int)floor((strtotime($today)-strtotime($lastYmd))/86400); $newGrowth=max(0,$newGrowth-$diff); $newDecay=min(7,$newDecay+$diff); }
            $newGrowth=min(21,$newGrowth+1); $newDecay=0; $newLast=date('Y-m-d H:i:s');

            $stmt=$conn->prepare("UPDATE grove_habits SET growth=?,decay=?,lastUpdated=? WHERE id=? AND user_id=?");
            $stmt->bind_param('iisii',$newGrowth,$newDecay,$newLast,$id,$user_id);
            $stmt->execute(); $stmt->close();

            echo json_encode(['status'=>'ok','growth'=>$newGrowth,'decay'=>$newDecay,'lastUpdated'=>$newLast]); exit;
        }

        http_response_code(400); echo json_encode(['error'=>'unknown_action']); exit;
    }

    http_response_code(405); echo json_encode(['error'=>'method_not_allowed']); exit;
}catch(Throwable $e){
    log_error("Exception: ".$e->getMessage());
    http_response_code(500); echo json_encode(['error'=>'server_error','message'=>$e->getMessage()]); exit;
}
