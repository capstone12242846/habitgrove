<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login/login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Your Grove | Habit Grove</title>

  <!-- Global styles -->
  <link rel="stylesheet" href="../styles/global.css" />
  <style>
    /* Grove-specific tweaks */
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      margin-bottom: 2rem;
    }

    .actions input[type="text"],
    .actions select {
      padding: 0.6rem 0.8rem;
      border-radius: var(--radius);
      border: 1px solid var(--border);
      background: var(--card-bg);
      color: var(--text);
      flex: 1 1 200px;
    }

    .actions button.add {
      background: var(--primary);
      color: #fff;
      padding: 0.6rem 1rem;
      border-radius: var(--radius);
      border: none;
      cursor: pointer;
      font-weight: 500;
      transition: background var(--transition);
    }

    .actions button.add:hover {
      background: var(--primary-dark);
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1.25rem;
    }

    .card {
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1rem;
      text-align: center;
      box-shadow: 0 2px 10px var(--shadow);
      position: relative;
      transition: transform var(--transition), box-shadow var(--transition);
    }

    .card:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 18px var(--shadow);
    }

    .card img {
      max-width: 120px;
      max-height: 120px;
      object-fit: contain;
      margin-bottom: 0.5rem;
    }

    .title {
      font-weight: 600;
      color: var(--primary-dark);
      margin-bottom: 0.25rem;
    }

    .meta {
      font-size: 0.85rem;
      color: var(--text-light);
      margin-bottom: 0.25rem;
    }

    .progress-bar {
      height: 8px;
      background: var(--border);
      border-radius: 6px;
      overflow: hidden;
      margin-top: 0.5rem;
    }

    .progress-bar > div {
      height: 100%;
      background: var(--primary);
      width: 0%;
      transition: width 0.35s ease-in-out;
    }

    .controls {
      display: flex;
      justify-content: center;
      gap: 0.5rem;
      margin-top: 0.75rem;
    }

    .btn-small {
      padding: 0.4rem 0.6rem;
      border-radius: var(--radius);
      border: 1px solid var(--border);
      background: transparent;
      cursor: pointer;
      font-size: 0.85rem;
      color: var(--text);
      transition: background var(--transition), color var(--transition);
    }

    .btn-small.danger {
      border-color: #ff7b7b;
      color: #ff4c4c;
    }

    .btn-small:hover {
      background: var(--bg-accent);
    }

    .small-muted {
      font-size: 0.85rem;
      color: var(--text-light);
      margin-top: 1rem;
      text-align: center;
    }

    .grow-anim {
      position: absolute;
      top: 35%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-weight: 700;
      color: var(--primary);
      opacity: 0;
      animation: popUp 0.9s ease-out forwards;
    }

    @keyframes popUp {
      0% { opacity: 0; transform: translate(-50%, 0) scale(.6); }
      30% { opacity: 1; transform: translate(-50%, -14px) scale(1.15); }
      70% { transform: translate(-50%, -22px) scale(1); }
      100% { opacity: 0; transform: translate(-50%, -60px) scale(.85); }
    }
  </style>
</head>
<body>
  <?php include('../navbar.php'); ?>

  <main class="container">
    <h1 class="hero-title">🌿 Your Grove</h1>
    <p class="hero-subtitle">Each habit grows a tree/flower. You may grow each habit <strong>once per day</strong>. Missed days cause decay.</p>

    <div class="actions">
      <input id="habitName" type="text" placeholder="Habit name (e.g., Morning walk)" />
      <select id="treeType">
        <option value="flower">Flower</option>
        <option value="oak">Oak</option>
        <option value="pine">Pine</option>
        <option value="garden">Garden</option>
        <option value="willow">Willow</option>
        <option value="fern">Fern</option>
        <option value="spruce">Spruce</option>
      </select>
      <button class="add" id="addBtn">Add Habit</button>
    </div>

    <div id="container">
      <div class="small-muted">Loading your grove…</div>
    </div>
  </main>

  <script>
  (function(){
    const API = 'save_grove_habit.php';
    const container = document.getElementById('container');
    const addBtn = document.getElementById('addBtn');
    const habitNameInput = document.getElementById('habitName');
    const treeTypeSelect = document.getElementById('treeType');

    function dateYMD(d){ return new Date(d).toISOString().split('T')[0]; }

    async function loadHabits() {
      const url = 'save_grove_habit.php?action=load';
      try {
        const res = await fetch(url, { credentials: 'same-origin' });
        const text = await res.text();
        try {
          const data = JSON.parse(text);
          renderHabits(data);
        } catch(err) {
          container.innerHTML = `<div class="small-muted">Failed loading grove. Check console.</div>`;
          console.log('Raw response:', text);
        }
      } catch (err) {
        container.innerHTML = `<div class="small-muted">Network error. Open console.</div>`;
      }
    }

    function getImagePath(h) {
      const type = (h.treeType || 'flower').toLowerCase();
      const growth = Math.max(1, Math.min(21, Math.round(h.growth || 0)));
      return `../images/${type}/${type}grow${growth}.png`;
    }

    function createCardHTML(h) {
      const progress = Math.min(100, Math.round(((h.growth||0)/21)*100));
      return `
        <div class="card" data-id="${h.id}">
          <img src="${getImagePath(h)}" alt="${h.name}" loading="lazy" onerror="this.onerror=null;this.src='../images/placeholder.png'">
          <div class="title">${h.name}</div>
          <div class="meta">Type: ${h.treeType} • Growth: ${h.growth || 0}/21</div>
          <div class="progress-bar"><div style="width:${progress}%;"></div></div>
          <div class="controls">
            <button class="btn-small btn-grow" data-id="${h.id}">Grow +1</button>
            <button class="btn-small btn-delete danger" data-id="${h.id}">Delete</button>
          </div>
        </div>
      `;
    }

    function renderHabits(habits) {
      if (!Array.isArray(habits) || habits.length===0){
        container.innerHTML='<div class="small-muted">No habits yet — add one to start growing your grove.</div>';
        return;
      }
      const grid = document.createElement('div');
      grid.className='grid';
      grid.innerHTML = habits.map(createCardHTML).join('');
      container.innerHTML='';
      container.appendChild(grid);

      grid.querySelectorAll('.btn-grow').forEach(btn=>{
        btn.addEventListener('click', ()=>onGrow(parseInt(btn.dataset.id), btn));
      });
      grid.querySelectorAll('.btn-delete').forEach(btn=>{
        btn.addEventListener('click', ()=>onDelete(parseInt(btn.dataset.id)));
      });
    }

    async function onGrow(id, btn){
      btn.disabled=true;
      try{
        const res = await fetch(API,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action:'grow', id})
        });
        const data = await res.json();
        if(data.error) return alert(data.error);
        await loadHabits();
      }catch(err){ alert(err.message); }
      finally{ btn.disabled=false; }
    }

    async function onDelete(id){
      if(!confirm('Delete this habit?')) return;
      try{
        const res = await fetch(API,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action:'delete', id})
        });
        const j = await res.json();
        if(j.error) throw new Error(j.error||'Delete failed');
        await loadHabits();
      }catch(err){ alert(err.message); }
    }

    addBtn.addEventListener('click', async ()=>{
      const name = habitNameInput.value.trim();
      const treeType = treeTypeSelect.value;
      if(!name) return alert('Type a habit name first.');
      addBtn.disabled=true;
      try{
        const res = await fetch(API,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action:'add', name, treeType})
        });
        const j = await res.json();
        if(j.error) throw new Error(j.error);
        habitNameInput.value='';
        await loadHabits();
      }catch(err){ alert(err.message); }
      finally{ addBtn.disabled=false; }
    });

    document.addEventListener('DOMContentLoaded', loadHabits);
  })();
  </script>
</body>
</html>
