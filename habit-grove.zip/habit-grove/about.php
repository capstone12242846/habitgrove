<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Habit Grove 🌱</title>
<link rel="stylesheet" href="styles/global.css">
<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: var(--bg);
  color: var(--text-dark);
  margin: 0;
  padding: 0;
}

main.container {
  max-width: 900px;
  margin: 3rem auto;
  padding: 0 1.5rem;
}

header {
  text-align: center;
  margin-bottom: 3rem;
}

header h1 {
  color: var(--primary-dark);
  font-size: 2.2rem;
  margin-bottom: 0.5rem;
}

header p {
  color: var(--text-light);
  font-size: 1rem;
}

/* About cards */
.about-card {
  background-color: var(--card-bg);
  border-radius: var(--radius);
  padding: 1.8rem 2rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 6px 20px var(--shadow);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.about-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px var(--shadow);
}

.about-card h2 {
  color: var(--primary-dark);
  margin-bottom: 0.8rem;
}

.about-card p {
  color: var(--text-light);
  line-height: 1.6;
}

/* Responsive */
@media (max-width: 600px) {
  header h1 { font-size: 1.8rem; }
  .about-card { padding: 1.4rem 1.5rem; }
}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<main class="container">
  <header>
    <h1>About Habit Grove 🌱</h1>
    <p>Transforming productivity into a thriving digital ecosystem</p>
  </header>

  <div class="about-card">
    <h2>Our Vision</h2>
    <p>
      Habit Grove is a gamified productivity platform that transforms habit formation and task completion into visual progress within a cozy, interactive environment. By integrating habit tracking, task management, and budget planning, the system nurtures personal growth into a meaningful, rewarding experience.
    </p>
  </div>

  <div class="about-card">
    <h2>Why Habit Grove?</h2>
    <p>
      Traditional productivity tools often lack emotional resonance. Habit Grove addresses this by mapping real-life actions to in-game rewards; each completed habit contributes to the development of a personalized virtual grove, fostering motivation through visual feedback and world-building.  
      <br><br>
      Our approach encourages sustainable behavior change by making productivity emotionally rewarding. It supports self-improvement, education, and mental wellness in a fun, engaging way.
    </p>
  </div>

  <div class="about-card">
    <h2>Our Mission</h2>
    <p>
      We aim to empower users to cultivate meaningful habits, celebrate progress, and maintain motivation through a beautiful, gamified digital environment. Habit Grove turns everyday actions into visible growth, helping you stay inspired and focused on your personal goals.
    </p>
  </div>
</main>

</body>
</html>
