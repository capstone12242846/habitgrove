<?php
// ────────────────────────────────
// Navbar for Habit Grove — works on all pages
// ────────────────────────────────

// Adjust this to your project folder name
$projectFolder = '/habit-grove';

// Absolute root path for images
$logoPath = $projectFolder . '/images/plant.png';
?>

<header class="nav">
  <div class="nav__inner">
    <!-- Brand / Logo -->
    <a href="<?= $projectFolder ?>/index.php" class="brand">
      <img src="<?= $logoPath ?>" alt="Habit Grove logo" class="brand__logo" />
      <span class="brand__text">HABIT GROVE</span>
    </a>

    <!-- Navigation links -->
    <nav class="links" aria-label="Primary">
      <a href="<?= $projectFolder ?>/grove/grove.php">Grove</a>
      <a href="<?= $projectFolder ?>/habit/habit.php">Habits</a>
      <a href="<?= $projectFolder ?>/task/task.php">Tasks</a>
      <a href="<?= $projectFolder ?>/budget/budget.php">Budget</a>
      <a href="<?= $projectFolder ?>/pomodoro/pomodoro.php">Pomodoro</a>
      <a href="<?= $projectFolder ?>/login/logout.php">Logout</a>
    </nav>
  </div>
</header>
