<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Tasks | Habit Grove</title>
  <link rel="stylesheet" href="../styles/global.css">
  <style>
/* ─── MAIN LAYOUT ───────────────────────── */
main {
    max-width: 1100px;
    margin: 2rem auto;
    padding: 1.5rem;
}

/* ─── PAGE TITLE ────────────────────────── */
h1 {
    margin-bottom: 1.5rem;
    color: var(--primary-dark);
}

/* ─── ACTIONS BAR ───────────────────────── */
.actions {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
}

.actions input[type="text"],
.actions textarea,
.actions select {
    padding: 0.6rem 1rem;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    font-size: 0.95rem;
    width: 200px;
}

.actions button.add {
    background: var(--primary);
    color: #fff;
    font-weight: 600;
    border: none;
    border-radius: var(--radius);
    padding: 0.6rem 1.2rem;
    cursor: pointer;
    transition: var(--transition);
}

.actions button.add:hover {
    background: var(--primary-dark);
}

/* ─── TASK GRID / CARDS ────────────────── */
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fill,minmax(260px,1fr));
    gap: 1rem;
}

.card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 1rem;
    box-shadow: 0 6px 20px var(--shadow);
    position: relative;
    overflow: hidden;
    transition: transform var(--transition), box-shadow var(--transition);
}

.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 25px var(--shadow);
}

.card h2 {
    margin-bottom: 0.5rem;
    color: var(--primary-dark);
}

.card p {
    margin-bottom: 0.8rem;
    color: var(--text-light);
    font-size: 0.95rem;
}

/* ─── CONTROLS & BUTTONS ───────────────── */
.controls {
    display: flex;
    flex-wrap: wrap;
    gap: 0.4rem;
    align-items: center;
    margin-top: 0.8rem;
}

.btn-small {
    padding: 0.4rem 0.7rem;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    background: transparent;
    cursor: pointer;
    font-size: 0.85rem;
    transition: var(--transition);
}

.btn-small:hover {
    background: var(--bg-accent);
}

.btn-small.danger {
    color: #ff7b7b;
    border-color: rgba(255,123,123,0.3);
}

.progress-bar-container {
    margin: 0.5rem 0;
}

.status-label {
    font-size: 0.85rem;
    margin-top: 0.25rem;
    font-weight: 500;
}

/* Status Colors */
.status-label.non-urgent { color: #facc15; }
.status-label.urgent { color: #dc2626; }
.status-label['on-hold'] { color: #6b7280; }
.status-label.complete { color: #16a34a; font-weight: 700; }

/* Slider */
input.status-slider {
    width: 100%;
    margin-top: 0.25rem;
}

/* Checkbox style */
input.task-complete {
    accent-color: var(--primary);
    cursor: pointer;
}

/* ─── RESPONSIVE ───────────────────────── */
@media(max-width: 768px) {
    .actions input,
    .actions textarea,
    .actions select {
        width: 100%;
    }
    .grid {
        grid-template-columns: 1fr;
    }
}
  </style>
</head>
<body>
  <?php include('../navbar.php'); ?>

  <main>
    <h1>🗒️ Your Tasks</h1>
    <div class="actions">
      <input id="taskTitle" type="text" placeholder="Task title">
      <textarea id="taskDesc" placeholder="Task description"></textarea>
      <select id="taskStatus">
        <option value="non-urgent">Non-Urgent</option>
        <option value="urgent">Urgent</option>
        <option value="on-hold">On Hold</option>
      </select>
      <button class="add" id="addBtn">Add Task</button>
    </div>

    <div id="container"><div class="small-muted">Loading your tasks…</div></div>
  </main>

  <script>
    (function(){
      const API = 'save_task.php';
      const container = document.getElementById('container');
      const addBtn = document.getElementById('addBtn');
      const titleInput = document.getElementById('taskTitle');
      const descInput = document.getElementById('taskDesc');
      const statusSelect = document.getElementById('taskStatus');

      function valueToStatus(val){
        switch(val){ case '0': return 'non-urgent'; case '1': return 'urgent'; case '2': return 'on-hold'; case '3': return 'complete'; default: return 'non-urgent'; }
      }
      function statusToValue(status){
        switch(status){ case 'non-urgent': return 0; case 'urgent': return 1; case 'on-hold': return 2; case 'complete': return 3; default: return 0; }
      }

      async function loadTasks(){
        try{
          const res = await fetch(API+'?action=load',{credentials:'same-origin'});
          const text = await res.text();
          try{
            const tasks = JSON.parse(text);
            renderTasks(tasks);
          }catch(err){
            container.innerHTML='<div class="error">Failed loading tasks. Check console.</div>';
            console.error(text);
          }
        }catch(e){
          container.innerHTML='<div class="error">Network error loading tasks.</div>';
          console.error(e);
        }
      }

      function renderTasks(tasks){
        if(!Array.isArray(tasks)||tasks.length===0){container.innerHTML='<div class="small-muted">No tasks yet.</div>'; return;}
        const grid = document.createElement('div'); grid.className='grid';
        grid.innerHTML = tasks.map(t=>`
          <div class="card" data-id="${t.id}">
            <h2>${escapeHtml(t.title)}</h2>
            <p>${escapeHtml(t.description||'')}</p>
            <div class="progress-bar-container">
              <input type="range" min="0" max="3" value="${statusToValue(t.status)}" class="status-slider" data-id="${t.id}">
              <div class="status-label ${t.status}">${t.status.replace('-',' ')}</div>
            </div>
            <div class="controls">
              <label>
                <input type="checkbox" class="task-complete" data-id="${t.id}" ${t.status==='complete'?'checked':''}>
                Complete
              </label>
              <button class="btn-small btn-edit" data-id="${t.id}">Edit</button>
              <button class="btn-small btn-delete danger" data-id="${t.id}">Delete</button>
            </div>
          </div>
        `).join('');
        container.innerHTML=''; container.appendChild(grid);

        // Events
        grid.querySelectorAll('.btn-delete').forEach(b=>b.addEventListener('click',()=>onDelete(parseInt(b.dataset.id))));
        grid.querySelectorAll('.task-complete').forEach(cb=>{
          cb.addEventListener('change',()=>onComplete(parseInt(cb.dataset.id),cb.checked));
        });
        grid.querySelectorAll('.status-slider').forEach(slider=>{
          slider.addEventListener('input',()=>onStatusChange(parseInt(slider.dataset.id),valueToStatus(slider.value)));
        });
      }

      function escapeHtml(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

      async function onDelete(id){
        if(!confirm('Delete this task?')) return;
        try{
          const res = await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',id})});
          const j=await res.json();
          if(j.error) throw new Error(j.error);
          await loadTasks();
        }catch(e){alert(e.message);}
      }

      async function onComplete(id,checked){
        try{
          const status = checked?'complete':'non-urgent';
          const res = await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'edit',id,status})});
          const j = await res.json(); if(j.error) throw new Error(j.error);
          await loadTasks();
        }catch(e){alert(e.message);}
      }

      async function onStatusChange(id,status){
        try{
          const res = await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'edit',id,status})});
          const j = await res.json(); if(j.error) throw new Error(j.error);
          await loadTasks();
        }catch(e){alert(e.message);}
      }

      addBtn.addEventListener('click',async ()=>{
        const title = titleInput.value.trim(); const desc=descInput.value.trim(); const status=statusSelect.value;
        if(!title) return alert('Type a title first.');
        addBtn.disabled=true;
        try{
          const res = await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'add',title,description:desc,status})});
          const j = await res.json(); if(j.error) throw new Error(j.error);
          titleInput.value=''; descInput.value=''; await loadTasks();
        }catch(e){alert(e.message);}
        finally{addBtn.disabled=false;}
      });

      document.addEventListener('DOMContentLoaded',loadTasks);
    })();
  </script>
</body>
</html>
