<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

$logFile = __DIR__.'/task_errors.log';
function log_error($msg){ global $logFile; @file_put_contents($logFile,date('Y-m-d H:i:s').' - '.$msg.PHP_EOL,FILE_APPEND|LOCK_EX); }

ini_set('display_errors',0); ini_set('log_errors',1);

$dbPath = __DIR__ . '/../db/connect.php';
if(!file_exists($dbPath)){
    log_error("db_connect.php not found at ".$dbPath);
    echo json_encode(['error'=>'db_connect.php missing']); exit;
}
require_once $dbPath;
if(!isset($conn)||!($conn instanceof mysqli)){echo json_encode(['error'=>'DB connection not found']);exit;}
if(!isset($_SESSION['user_id'])){http_response_code(401);echo json_encode(['error'=>'Not logged in']);exit;}
$user_id = (int)$_SESSION['user_id'];

// create table if missing
$createSQL="CREATE TABLE IF NOT EXISTS tasks (
id BIGINT PRIMARY KEY,
user_id INT NOT NULL,
title VARCHAR(255),
description TEXT,
status VARCHAR(50) DEFAULT 'non-urgent',
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
if(!$conn->query($createSQL)){log_error("CREATE TABLE failed: ".$conn->error);}

// helper
function fetch_tasks(mysqli $conn,int $user_id):array{
    $stmt=$conn->prepare("SELECT id,title,description,status FROM tasks WHERE user_id=? ORDER BY id DESC");
    if(!$stmt)return[];
    $stmt->bind_param('i',$user_id);
    $stmt->execute();
    $res=$stmt->get_result();
    $rows=$res->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $rows;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? null;
try{
    if($method==='GET' && ($action==='load'||$action===null)){
        echo json_encode(fetch_tasks($conn,$user_id)); exit;
    }

    $raw=file_get_contents('php://input'); $data=json_decode($raw,true);
    if($method==='POST' && is_array($data)){
        $act=$data['action']??null;

        if($act==='add'){
            $title=trim((string)($data['title']??'')); $desc=trim((string)($data['description']??''));
            $status=trim((string)($data['status']??'non-urgent'));
            if($title===''){http_response_code(400); echo json_encode(['error'=>'Title required']); exit;}
            $id=(int)round(microtime(true)*1000);
            $stmt=$conn->prepare("INSERT INTO tasks (id,user_id,title,description,status) VALUES (?,?,?,?,?)");
            if(!$stmt) throw new Exception("Prepare failed: ".$conn->error);
            $stmt->bind_param('iisss',$id,$user_id,$title,$desc,$status);
            if(!$stmt->execute()) throw new Exception("Insert failed: ".$stmt->error);
            $stmt->close();
            echo json_encode(['status'=>'ok','id'=>$id]); exit;
        }

        if($act==='delete'){
            $id=(int)($data['id']??0);
            if($id<=0){http_response_code(400); echo json_encode(['error'=>'invalid id']); exit;}
            $stmt=$conn->prepare("DELETE FROM tasks WHERE id=? AND user_id=?");
            $stmt->bind_param('ii',$id,$user_id);
            $stmt->execute();
            $stmt->close();
            echo json_encode(['status'=>'ok']); exit;
        }

        if($act==='edit'){
            $id=(int)($data['id']??0);
            $status=trim((string)($data['status']??'non-urgent'));
            if($id<=0){http_response_code(400); echo json_encode(['error'=>'invalid id']); exit;}
            $stmt=$conn->prepare("UPDATE tasks SET status=? WHERE id=? AND user_id=?");
            $stmt->bind_param('sii',$status,$id,$user_id);
            $stmt->execute();
            $stmt->close();
            echo json_encode(['status'=>'ok']); exit;
        }

        http_response_code(400); echo json_encode(['error'=>'unknown_action']); exit;
    }

    http_response_code(405); echo json_encode(['error'=>'method_not_allowed']); exit;
}catch(Throwable $e){
    log_error("Exception: ".$e->getMessage());
    http_response_code(500); echo json_encode(['error'=>'server_error','message'=>$e->getMessage()]);
}
