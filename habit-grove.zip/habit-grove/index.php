<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Habit Grove | Home</title>

  <!-- ✅ Correct path to CSS -->
  <link rel="stylesheet" href="styles/global.css" />
</head>

<body>
  <!-- ✅ Navbar in root -->
  <?php include('navbar.php'); ?>

  <main class="container">
    <section class="hero">
      <h1 class="hero-title">Welcome to <span class="accent">Habit Grove</span> 🌱</h1>
      <p class="hero-subtitle">
        Nurture your daily routines — track habits, manage tasks, plan your budget, and watch your grove grow with you.
      </p>

      <?php if (!isset($_SESSION["user_id"])): ?>
        <div class="hero-buttons">
          <a href="login/login.php" class="nav-btn login">Get Started</a>
          <a href="login/register.php" class="nav-btn logout">Create Account</a>
        </div>
      <?php else: ?>
        <div class="hero-buttons">
          <a href="grove/grove.php" class="nav-btn login">Go to Your Grove</a>
        </div>
<br>
	  <a href="about.php" class="nav-btn login">About</a>
<br>
<br>
<br>
<a href="login/logout.php" class="nav-btn logout">Logout</a>
      <?php endif; ?>
    </section>

    <section class="features">
      <div class="feature">
        <h2>🌿 Grove</h2>
        <p>Watch your virtual plants grow as you build positive habits and consistency.</p>
      </div>

      <div class="feature">
        <h2>🗓️ Tasks</h2>
        <p>Organize and prioritize your day with a clean, motivating task manager.</p>
      </div>

      <div class="feature">
        <h2>💰 Budget</h2>
        <p>Track your spending and saving — grow your financial forest too!</p>
      </div>

      <div class="feature">
        <h2>⏱️ Pomodoro</h2>
        <p>Stay productive with focused sessions using the Pomodoro timer.</p>
      </div>
    </section>
  </main>

  <footer>
    &copy; <?= date("Y"); ?> Habit Grove — Grow your best self 🌿
  </footer>
</body>
</html>
